// Application State
let state = {
  currentUser: null,
  currentPage: 'home',
  jobs: [],
  applications: [],
  filters: {
    keyword: '',
    location: '',
    jobType: '',
    salaryMin: '',
    salaryMax: ''
  },
  displayedJobsCount: 6
};

// Demo Accounts
const demoAccounts = [
  {
    id: 'emp1',
    email: 'emp1@test.com',
    password: 'pass123',
    role: 'employer',
    name: 'John Employer',
    company: 'TechCorp Solutions'
  },
  {
    id: 'seek1',
    email: 'seek1@test.com',
    password: 'pass123',
    role: 'seeker',
    name: 'Jane Seeker',
    skills: ['JavaScript', 'React', 'Node.js']
  }
];

// Sample Applications Data
const sampleApplications = [
  {
    id: 'app1',
    job_id: 'job1',
    job_title: 'Senior React Developer',
    company: 'TechCorp Solutions',
    seeker_id: 'seek1',
    seeker_name: 'Jane Seeker',
    seeker_email: 'seek1@test.com',
    seeker_skills: ['JavaScript', 'React', 'Node.js'],
    resume_file: 'jane_seeker_resume.pdf',
    cover_letter: 'I am excited to apply for the Senior React Developer position. With over 5 years of experience building scalable React applications, I am confident I can contribute to your team. I have deep expertise in React, Redux, TypeScript, and modern frontend development practices. In my current role, I lead a team of frontend developers and have successfully delivered multiple high-impact projects.',
    status: 'pending',
    applied_date: '2024-10-23T14:30:00.000Z',
    viewed_by_employer: false,
    employer_notes: ''
  },
  {
    id: 'app2',
    job_id: 'job1',
    job_title: 'Senior React Developer',
    company: 'TechCorp Solutions',
    seeker_id: 'seek2',
    seeker_name: 'Mike Developer',
    seeker_email: 'seek2@test.com',
    seeker_skills: ['React', 'TypeScript', 'Redux', 'GraphQL'],
    resume_file: 'mike_developer_resume.pdf',
    cover_letter: 'I am writing to express my interest in the Senior React Developer role at TechCorp Solutions. My 6 years of experience in frontend development, particularly with React and TypeScript, aligns perfectly with your requirements. I have worked on large-scale applications serving millions of users and am passionate about creating exceptional user experiences.',
    status: 'pending',
    applied_date: '2024-10-22T09:15:00.000Z',
    viewed_by_employer: false,
    employer_notes: ''
  },
  {
    id: 'app3',
    job_id: 'job1',
    job_title: 'Senior React Developer',
    company: 'TechCorp Solutions',
    seeker_id: 'seek3',
    seeker_name: 'Sarah Johnson',
    seeker_email: 'seek3@test.com',
    seeker_skills: ['React', 'JavaScript', 'CSS', 'HTML'],
    resume_file: 'sarah_johnson_resume.pdf',
    cover_letter: 'I am thrilled about the opportunity to join TechCorp Solutions as a Senior React Developer. With my background in frontend architecture and passion for clean code, I can help drive your projects forward. I have mentored junior developers and led technical initiatives that improved performance by 40%.',
    status: 'reviewed',
    applied_date: '2024-10-21T16:45:00.000Z',
    reviewed_date: '2024-10-24T10:00:00.000Z',
    viewed_by_employer: true,
    employer_notes: ''
  },
  {
    id: 'app4',
    job_id: 'job2',
    job_title: 'Full Stack Engineer',
    company: 'StartupXYZ',
    seeker_id: 'seek1',
    seeker_name: 'Jane Seeker',
    seeker_email: 'seek1@test.com',
    seeker_skills: ['JavaScript', 'React', 'Node.js', 'MongoDB'],
    resume_file: 'jane_seeker_resume.pdf',
    cover_letter: 'I would love to contribute to StartupXYZ as a Full Stack Engineer. My experience spans both frontend and backend development, and I thrive in fast-paced startup environments. I have built complete features from database design to user interface, ensuring seamless integration and excellent performance.',
    status: 'pending',
    applied_date: '2024-10-24T11:20:00.000Z',
    viewed_by_employer: false,
    employer_notes: ''
  }
];

// Sample Jobs Data
const sampleJobs = [
  {
    id: 'job1',
    title: 'Senior React Developer',
    company: 'TechCorp Solutions',
    location: 'San Francisco, CA',
    salary_min: 80000,
    salary_max: 120000,
    job_type: 'full-time',
    description: 'We are seeking an experienced React developer to join our growing team. You will work on cutting-edge projects and collaborate with talented engineers.',
    qualifications: '5+ years experience with React, TypeScript, and Node.js. Strong problem-solving skills.',
    responsibilities: 'Lead frontend development, mentor junior developers, architect scalable solutions, conduct code reviews.',
    skills: ['React', 'TypeScript', 'Node.js', 'Redux', 'GraphQL'],
    posted_date: '2024-10-20T10:00:00.000Z',
    application_count: 15,
    view_count: 234,
    employer_id: 'emp1',
    active: true
  },
  {
    id: 'job2',
    title: 'Full Stack Engineer',
    company: 'StartupXYZ',
    location: 'Remote',
    salary_min: 70000,
    salary_max: 110000,
    job_type: 'full-time',
    description: 'Join our fast-paced startup as a full stack engineer. Work on exciting products from concept to deployment.',
    qualifications: '3+ years full stack development experience. Comfortable with both frontend and backend.',
    responsibilities: 'Build features end-to-end, collaborate with product team, maintain high code quality.',
    skills: ['JavaScript', 'React', 'Node.js', 'MongoDB', 'AWS'],
    posted_date: '2024-10-18T14:30:00.000Z',
    application_count: 23,
    view_count: 456,
    employer_id: 'emp2',
    active: true
  },
  {
    id: 'job3',
    title: 'UI/UX Designer',
    company: 'DesignHub',
    location: 'New York, NY',
    salary_min: 60000,
    salary_max: 90000,
    job_type: 'full-time',
    description: 'Create beautiful and intuitive user experiences for our suite of products. Work closely with developers and product managers.',
    qualifications: '4+ years design experience, Portfolio required. Expert in Figma or Sketch.',
    responsibilities: 'Design user interfaces, conduct user research, create prototypes, maintain design systems.',
    skills: ['Figma', 'Sketch', 'Adobe XD', 'User Research', 'Prototyping'],
    posted_date: '2024-10-22T09:15:00.000Z',
    application_count: 31,
    view_count: 567,
    employer_id: 'emp3',
    active: true
  },
  {
    id: 'job4',
    title: 'Python Developer',
    company: 'DataSoft',
    location: 'Boston, MA',
    salary_min: 75000,
    salary_max: 100000,
    job_type: 'full-time',
    description: 'Work on data processing pipelines and backend services using Python. Great opportunity for growth.',
    qualifications: '3+ years Python development. Experience with Django or Flask.',
    responsibilities: 'Develop APIs, optimize performance, work with databases, write clean code.',
    skills: ['Python', 'Django', 'PostgreSQL', 'Redis', 'Docker'],
    posted_date: '2024-10-15T11:00:00.000Z',
    application_count: 18,
    view_count: 321,
    employer_id: 'emp4',
    active: true
  },
  {
    id: 'job5',
    title: 'DevOps Engineer',
    company: 'CloudTech',
    location: 'Seattle, WA',
    salary_min: 90000,
    salary_max: 130000,
    job_type: 'full-time',
    description: 'Build and maintain our cloud infrastructure. Automate deployment processes and ensure system reliability.',
    qualifications: '5+ years DevOps experience. Strong knowledge of AWS and Kubernetes.',
    responsibilities: 'Manage CI/CD pipelines, monitor systems, optimize infrastructure costs.',
    skills: ['AWS', 'Kubernetes', 'Docker', 'Terraform', 'Jenkins'],
    posted_date: '2024-10-19T16:45:00.000Z',
    application_count: 12,
    view_count: 289,
    employer_id: 'emp5',
    active: true
  },
  {
    id: 'job6',
    title: 'Product Manager',
    company: 'Innovate Inc',
    location: 'Austin, TX',
    salary_min: 85000,
    salary_max: 125000,
    job_type: 'full-time',
    description: 'Lead product strategy and execution. Work with cross-functional teams to deliver amazing products.',
    qualifications: '4+ years product management. Strong analytical and communication skills.',
    responsibilities: 'Define roadmap, prioritize features, analyze metrics, collaborate with stakeholders.',
    skills: ['Product Strategy', 'Agile', 'Analytics', 'User Stories', 'Roadmapping'],
    posted_date: '2024-10-21T13:20:00.000Z',
    application_count: 25,
    view_count: 412,
    employer_id: 'emp6',
    active: true
  },
  {
    id: 'job7',
    title: 'Data Scientist',
    company: 'AI Labs',
    location: 'San Francisco, CA',
    salary_min: 95000,
    salary_max: 140000,
    job_type: 'full-time',
    description: 'Apply machine learning to solve complex business problems. Work with large datasets and cutting-edge AI.',
    qualifications: 'PhD or Masters in related field. Strong Python and ML skills.',
    responsibilities: 'Build ML models, analyze data, present findings, collaborate with engineers.',
    skills: ['Python', 'TensorFlow', 'Pandas', 'SQL', 'Statistics'],
    posted_date: '2024-10-17T10:30:00.000Z',
    application_count: 29,
    view_count: 523,
    employer_id: 'emp7',
    active: true
  },
  {
    id: 'job8',
    title: 'Mobile Developer',
    company: 'AppWorks',
    location: 'Los Angeles, CA',
    salary_min: 70000,
    salary_max: 105000,
    job_type: 'full-time',
    description: 'Build native mobile applications for iOS and Android. Create smooth, responsive user experiences.',
    qualifications: '3+ years mobile development. Experience with React Native or Flutter preferred.',
    responsibilities: 'Develop mobile apps, optimize performance, fix bugs, collaborate with designers.',
    skills: ['React Native', 'iOS', 'Android', 'JavaScript', 'Swift'],
    posted_date: '2024-10-16T14:00:00.000Z',
    application_count: 22,
    view_count: 398,
    employer_id: 'emp8',
    active: true
  },
  {
    id: 'job9',
    title: 'QA Engineer',
    company: 'TestPro',
    location: 'Chicago, IL',
    salary_min: 55000,
    salary_max: 80000,
    job_type: 'full-time',
    description: 'Ensure quality through comprehensive testing. Automate test cases and improve QA processes.',
    qualifications: '2+ years QA experience. Knowledge of automation tools.',
    responsibilities: 'Write test cases, perform testing, report bugs, improve QA processes.',
    skills: ['Selenium', 'Jest', 'Cypress', 'Testing', 'Automation'],
    posted_date: '2024-10-14T09:00:00.000Z',
    application_count: 16,
    view_count: 267,
    employer_id: 'emp9',
    active: true
  },
  {
    id: 'job10',
    title: 'Marketing Specialist',
    company: 'GrowthCo',
    location: 'Miami, FL',
    salary_min: 50000,
    salary_max: 75000,
    job_type: 'part-time',
    description: 'Drive marketing campaigns and grow our brand. Work with creative team on engaging content.',
    qualifications: '2+ years marketing experience. Strong writing and analytical skills.',
    responsibilities: 'Plan campaigns, create content, analyze metrics, manage social media.',
    skills: ['Marketing', 'SEO', 'Content', 'Analytics', 'Social Media'],
    posted_date: '2024-10-13T11:30:00.000Z',
    application_count: 19,
    view_count: 345,
    employer_id: 'emp10',
    active: true
  },
  {
    id: 'job11',
    title: 'Content Writer',
    company: 'MediaHub',
    location: 'Remote',
    salary_min: 40000,
    salary_max: 60000,
    job_type: 'contract',
    description: 'Create engaging content for blogs, websites, and marketing materials. Remote, flexible hours.',
    qualifications: 'Strong writing skills. Portfolio of published work required.',
    responsibilities: 'Write articles, edit content, research topics, meet deadlines.',
    skills: ['Writing', 'Editing', 'SEO', 'Research', 'WordPress'],
    posted_date: '2024-10-12T15:45:00.000Z',
    application_count: 34,
    view_count: 478,
    employer_id: 'emp11',
    active: true
  },
  {
    id: 'job12',
    title: 'Sales Representative',
    company: 'SalesPro',
    location: 'Dallas, TX',
    salary_min: 45000,
    salary_max: 70000,
    job_type: 'full-time',
    description: 'Build relationships with clients and drive sales. Great commission structure and growth opportunities.',
    qualifications: '1+ years sales experience. Excellent communication skills.',
    responsibilities: 'Generate leads, close deals, maintain client relationships, meet targets.',
    skills: ['Sales', 'Communication', 'CRM', 'Negotiation', 'Networking'],
    posted_date: '2024-10-11T10:15:00.000Z',
    application_count: 27,
    view_count: 389,
    employer_id: 'emp12',
    active: true
  }
];

// Initialize app
function init() {
  // Initialize with sample data
  state.jobs = [...sampleJobs];
  state.applications = [...sampleApplications];
  
  // Update job application counts based on sample applications
  state.jobs.forEach(job => {
    const appCount = state.applications.filter(app => app.job_id === job.id).length;
    if (appCount > 0) {
      job.application_count = appCount;
    }
  });
  
  setupEventListeners();
  renderCurrentPage();
  updateStats();
  updateNotificationBadge();
}

// Setup event listeners
function setupEventListeners() {
  // Logo click
  document.querySelector('.logo').addEventListener('click', () => navigateTo('home'));
  
  // Navigation
  document.querySelectorAll('[data-route]').forEach(el => {
    el.addEventListener('click', (e) => {
      e.preventDefault();
      navigateTo(e.target.dataset.route);
    });
  });
  
  // Mobile menu
  document.getElementById('mobileMenuBtn').addEventListener('click', () => {
    document.getElementById('nav').classList.toggle('active');
  });
  
  // Auth buttons
  document.getElementById('loginBtn').addEventListener('click', () => navigateTo('login'));
  document.getElementById('registerBtn').addEventListener('click', () => navigateTo('register'));
  document.getElementById('logoutBtn').addEventListener('click', logout);
  
  // Forms
  document.getElementById('loginForm').addEventListener('submit', handleLogin);
  document.getElementById('registerForm').addEventListener('submit', handleRegister);
  document.getElementById('registerRole').addEventListener('change', (e) => {
    document.getElementById('companyField').style.display = e.target.value === 'employer' ? 'block' : 'none';
  });
  
  // Search and filters
  document.getElementById('searchBtn').addEventListener('click', applyFilters);
  document.getElementById('clearFiltersBtn').addEventListener('click', clearFilters);
  document.getElementById('searchKeyword').addEventListener('input', applyFilters);
  document.getElementById('searchLocation').addEventListener('input', applyFilters);
  document.getElementById('searchJobType').addEventListener('change', applyFilters);
  document.getElementById('salaryMin').addEventListener('input', applyFilters);
  document.getElementById('salaryMax').addEventListener('input', applyFilters);
  
  // Load more
  document.getElementById('loadMoreBtn').addEventListener('click', loadMoreJobs);
  
  // Application modal
  document.getElementById('closeApplicationModal').addEventListener('click', closeApplicationModal);
  document.getElementById('applicationModalOverlay').addEventListener('click', closeApplicationModal);
  document.getElementById('cancelApplicationBtn').addEventListener('click', closeApplicationModal);
  document.getElementById('resumeUploadBtn').addEventListener('click', () => {
    document.getElementById('resumeUpload').click();
  });
  document.getElementById('resumeUpload').addEventListener('change', (e) => {
    const fileName = e.target.files[0]?.name || 'No file chosen';
    document.getElementById('resumeFileName').textContent = fileName;
  });
  document.getElementById('coverLetter').addEventListener('input', (e) => {
    document.getElementById('coverLetterCount').textContent = `${e.target.value.length}/1000`;
  });
  document.getElementById('submitApplicationBtn').addEventListener('click', submitApplication);
  
  // Job post modal
  document.getElementById('postJobBtn').addEventListener('click', openJobPostModal);
  document.getElementById('postJobBtn2').addEventListener('click', openJobPostModal);
  document.getElementById('closeJobPostModal').addEventListener('click', closeJobPostModal);
  document.getElementById('jobPostModalOverlay').addEventListener('click', closeJobPostModal);
  document.getElementById('cancelJobPostBtn').addEventListener('click', closeJobPostModal);
  document.getElementById('submitJobPostBtn').addEventListener('click', submitJobPost);
  
  // Dashboard tabs
  document.querySelectorAll('.tab-btn').forEach(btn => {
    btn.addEventListener('click', (e) => {
      const tabName = e.target.dataset.tab;
      switchDashboardTab(tabName);
    });
  });
  
  // Application detail modal
  document.getElementById('closeApplicationDetail').addEventListener('click', closeApplicationDetailModal);
  document.getElementById('applicationDetailOverlay').addEventListener('click', closeApplicationDetailModal);
  document.getElementById('closeApplicationDetailBtn').addEventListener('click', closeApplicationDetailModal);
  document.getElementById('acceptApplicationBtn').addEventListener('click', () => handleApplicationAction('accept'));
  document.getElementById('rejectApplicationBtn').addEventListener('click', () => handleApplicationAction('reject'));
  
  // Confirmation dialog
  document.getElementById('closeConfirmation').addEventListener('click', closeConfirmationDialog);
  document.getElementById('confirmationOverlay').addEventListener('click', closeConfirmationDialog);
  document.getElementById('cancelConfirmation').addEventListener('click', closeConfirmationDialog);
  
  // Application filters
  document.getElementById('applicantSearch')?.addEventListener('input', filterApplications);
  document.getElementById('statusFilter')?.addEventListener('change', filterApplications);
}

// Navigation
function navigateTo(page) {
  // Check authentication
  if (page === 'dashboard' && !state.currentUser) {
    navigateTo('login');
    return;
  }
  
  if ((page === 'login' || page === 'register') && state.currentUser) {
    navigateTo('home');
    return;
  }
  
  state.currentPage = page;
  
  // Close mobile menu
  document.getElementById('nav').classList.remove('active');
  
  renderCurrentPage();
}

function renderCurrentPage() {
  // Hide all pages
  document.querySelectorAll('.page').forEach(page => {
    page.style.display = 'none';
  });
  
  // Show current page
  if (state.currentPage === 'home') {
    document.getElementById('homePage').style.display = 'block';
    renderHomePage();
  } else if (state.currentPage === 'login') {
    document.getElementById('loginPage').style.display = 'block';
  } else if (state.currentPage === 'register') {
    document.getElementById('registerPage').style.display = 'block';
  } else if (state.currentPage === 'dashboard') {
    if (state.currentUser.role === 'seeker') {
      document.getElementById('seekerDashboard').style.display = 'block';
      renderSeekerDashboard();
    } else if (state.currentUser.role === 'employer') {
      document.getElementById('employerDashboard').style.display = 'block';
      renderEmployerDashboard();
    }
  }
  
  window.scrollTo(0, 0);
}

// Update auth UI
function updateAuthUI() {
  const navAuth = document.getElementById('navAuth');
  const navUser = document.getElementById('navUser');
  const dashboardLink = document.querySelector('.dashboard-link');
  
  if (state.currentUser) {
    navAuth.style.display = 'none';
    navUser.style.display = 'flex';
    dashboardLink.style.display = 'block';
    document.getElementById('userName').textContent = state.currentUser.name;
    document.getElementById('userRole').textContent = state.currentUser.role;
    updateNotificationBadge();
  } else {
    navAuth.style.display = 'flex';
    navUser.style.display = 'none';
    dashboardLink.style.display = 'none';
    document.getElementById('notificationBell').style.display = 'none';
  }
}

// Authentication
function handleLogin(e) {
  e.preventDefault();
  
  const email = document.getElementById('loginEmail').value;
  const password = document.getElementById('loginPassword').value;
  
  const account = demoAccounts.find(acc => acc.email === email && acc.password === password);
  
  if (account) {
    state.currentUser = account;
    updateAuthUI();
    showToast('Login successful!', 'success');
    
    setTimeout(() => {
      navigateTo('dashboard');
    }, 300);
  } else {
    showToast('Invalid email or password', 'error');
  }
}

function handleRegister(e) {
  e.preventDefault();
  
  const name = document.getElementById('registerName').value;
  const email = document.getElementById('registerEmail').value;
  const password = document.getElementById('registerPassword').value;
  const role = document.getElementById('registerRole').value;
  const company = document.getElementById('registerCompany').value;
  
  if (!role) {
    showToast('Please select a role', 'error');
    return;
  }
  
  // Check if email already exists
  if (demoAccounts.find(acc => acc.email === email)) {
    showToast('Email already registered', 'error');
    return;
  }
  
  const newUser = {
    id: `user_${Date.now()}`,
    email,
    password,
    role,
    name,
    company: role === 'employer' ? company : undefined
  };
  
  demoAccounts.push(newUser);
  state.currentUser = newUser;
  updateAuthUI();
  showToast('Registration successful!', 'success');
  
  setTimeout(() => {
    navigateTo('dashboard');
  }, 300);
}

function logout() {
  state.currentUser = null;
  updateAuthUI();
  showToast('Logged out successfully', 'success');
  navigateTo('home');
}

// Home Page
function renderHomePage() {
  renderFeaturedJobs();
  renderAllJobs();
}

function renderFeaturedJobs() {
  const container = document.getElementById('featuredJobs');
  const featured = state.jobs.filter(job => job.active).slice(0, 3);
  
  container.innerHTML = featured.map(job => createJobCard(job)).join('');
  
  // Add event listeners
  featured.forEach(job => {
    const card = document.querySelector(`[data-job-id="${job.id}"]`);
    if (card) {
      const applyBtn = card.querySelector('.apply-btn');
      if (applyBtn) {
        applyBtn.addEventListener('click', (e) => {
          e.stopPropagation();
          if (state.currentUser && state.currentUser.role === 'seeker') {
            openApplicationModal(job);
          } else if (!state.currentUser) {
            navigateTo('login');
          }
        });
      }
    }
  });
}

function renderAllJobs() {
  const filteredJobs = getFilteredJobs();
  const displayJobs = filteredJobs.slice(0, state.displayedJobsCount);
  
  const container = document.getElementById('jobsList');
  const emptyState = document.getElementById('emptyState');
  const loadMoreContainer = document.getElementById('loadMoreContainer');
  const jobsCount = document.getElementById('jobsCount');
  
  jobsCount.textContent = `${filteredJobs.length} jobs found`;
  
  if (displayJobs.length === 0) {
    container.innerHTML = '';
    emptyState.style.display = 'block';
    loadMoreContainer.style.display = 'none';
  } else {
    container.innerHTML = displayJobs.map(job => createJobCard(job)).join('');
    emptyState.style.display = 'none';
    loadMoreContainer.style.display = filteredJobs.length > state.displayedJobsCount ? 'block' : 'none';
    
    // Add event listeners
    displayJobs.forEach(job => {
      const card = document.querySelector(`[data-job-id="${job.id}"]`);
      if (card) {
        const applyBtn = card.querySelector('.apply-btn');
        if (applyBtn) {
          applyBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            if (state.currentUser && state.currentUser.role === 'seeker') {
              openApplicationModal(job);
            } else if (!state.currentUser) {
              navigateTo('login');
            }
          });
        }
      }
    });
  }
}

function createJobCard(job) {
  const alreadyApplied = state.applications.some(app => 
    app.job_id === job.id && app.seeker_id === state.currentUser?.id
  );
  
  const skills = job.skills.slice(0, 3);
  const moreSkills = job.skills.length > 3 ? job.skills.length - 3 : 0;
  
  return `
    <div class="job-card" data-job-id="${job.id}">
      <div class="job-card-header">
        <h3 class="job-title">${job.title}</h3>
        <p class="job-company">${job.company}</p>
      </div>
      <div class="job-card-body">
        <div class="job-info">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path>
            <circle cx="12" cy="10" r="3"></circle>
          </svg>
          <span>${job.location}</span>
        </div>
        <div class="job-info">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <line x1="12" y1="1" x2="12" y2="23"></line>
            <path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"></path>
          </svg>
          <span>$${(job.salary_min / 1000).toFixed(0)}k - $${(job.salary_max / 1000).toFixed(0)}k</span>
        </div>
        <span class="job-type-badge">${job.job_type}</span>
        <div class="job-meta">
          <span>${getRelativeTime(job.posted_date)}</span>
          <span>•</span>
          <span>${job.application_count} applications</span>
          <span>•</span>
          <span>${job.view_count} views</span>
        </div>
        ${skills.length > 0 ? `
          <div class="job-skills">
            ${skills.map(skill => `<span class="skill-tag">${skill}</span>`).join('')}
            ${moreSkills > 0 ? `<span class="skill-tag">+${moreSkills} more</span>` : ''}
          </div>
        ` : ''}
      </div>
      <div class="job-card-footer">
        ${state.currentUser && state.currentUser.role === 'seeker' ? 
          alreadyApplied ? 
            `<button class="btn btn-outline btn-full-width" disabled>Already Applied</button>` :
            `<button class="btn btn-primary btn-full-width apply-btn">Apply Now</button>` :
          !state.currentUser ?
            `<a href="#" class="btn btn-primary btn-full-width" data-route="login">Login to Apply</a>` :
            `<button class="btn btn-outline btn-full-width" disabled>For Job Seekers Only</button>`
        }
      </div>
    </div>
  `;
}

// Filters
function applyFilters() {
  state.filters.keyword = document.getElementById('searchKeyword').value.toLowerCase();
  state.filters.location = document.getElementById('searchLocation').value.toLowerCase();
  state.filters.jobType = document.getElementById('searchJobType').value;
  state.filters.salaryMin = document.getElementById('salaryMin').value;
  state.filters.salaryMax = document.getElementById('salaryMax').value;
  
  state.displayedJobsCount = 6;
  renderAllJobs();
}

function clearFilters() {
  document.getElementById('searchKeyword').value = '';
  document.getElementById('searchLocation').value = '';
  document.getElementById('searchJobType').value = '';
  document.getElementById('salaryMin').value = '';
  document.getElementById('salaryMax').value = '';
  
  state.filters = {
    keyword: '',
    location: '',
    jobType: '',
    salaryMin: '',
    salaryMax: ''
  };
  
  state.displayedJobsCount = 6;
  renderAllJobs();
}

function getFilteredJobs() {
  return state.jobs.filter(job => {
    if (!job.active) return false;
    
    if (state.filters.keyword) {
      const keyword = state.filters.keyword;
      if (!job.title.toLowerCase().includes(keyword) && 
          !job.company.toLowerCase().includes(keyword) &&
          !job.description.toLowerCase().includes(keyword)) {
        return false;
      }
    }
    
    if (state.filters.location && !job.location.toLowerCase().includes(state.filters.location)) {
      return false;
    }
    
    if (state.filters.jobType && job.job_type !== state.filters.jobType) {
      return false;
    }
    
    if (state.filters.salaryMin) {
      const min = parseInt(state.filters.salaryMin);
      if (job.salary_max < min) return false;
    }
    
    if (state.filters.salaryMax) {
      const max = parseInt(state.filters.salaryMax);
      if (job.salary_min > max) return false;
    }
    
    return true;
  });
}

function loadMoreJobs() {
  state.displayedJobsCount += 6;
  renderAllJobs();
}

// Application Modal
function openApplicationModal(job) {
  const modal = document.getElementById('applicationModal');
  const summary = document.getElementById('applicationJobSummary');
  
  summary.innerHTML = `
    <h4>${job.title}</h4>
    <p>${job.company}</p>
    <p>${job.location} • ${job.job_type}</p>
  `;
  
  document.getElementById('resumeFileName').textContent = 'No file chosen';
  document.getElementById('coverLetter').value = '';
  document.getElementById('coverLetterCount').textContent = '0/1000';
  
  modal.dataset.jobId = job.id;
  modal.style.display = 'block';
}

function closeApplicationModal() {
  document.getElementById('applicationModal').style.display = 'none';
}

function submitApplication() {
  const modal = document.getElementById('applicationModal');
  const jobId = modal.dataset.jobId;
  const resumeFile = document.getElementById('resumeUpload').files[0];
  const coverLetter = document.getElementById('coverLetter').value;
  
  if (!resumeFile) {
    showToast('Please upload your resume', 'error');
    return;
  }
  
  if (!coverLetter.trim()) {
    showToast('Please write a cover letter', 'error');
    return;
  }
  
  // Create application
  const job = state.jobs.find(j => j.id === jobId);
  const application = {
    id: `app_${Date.now()}`,
    job_id: jobId,
    job_title: job ? job.title : 'Unknown Job',
    company: job ? job.company : 'Unknown Company',
    seeker_id: state.currentUser.id,
    seeker_name: state.currentUser.name,
    seeker_email: state.currentUser.email,
    seeker_skills: state.currentUser.skills || [],
    resume_file: resumeFile.name,
    cover_letter: coverLetter,
    status: 'pending',
    applied_date: new Date().toISOString(),
    viewed_by_employer: false,
    employer_notes: ''
  };
  
  state.applications.push(application);
  
  // Update job application count
  const jobToUpdate = state.jobs.find(j => j.id === jobId);
  if (jobToUpdate) {
    jobToUpdate.application_count++;
  }
  
  // Update notification badge for employer
  updateNotificationBadge();
  
  closeApplicationModal();
  showToast('Application submitted successfully!', 'success');
  
  // Refresh current view
  if (state.currentPage === 'home') {
    renderHomePage();
  }
  updateStats();
}

// Job Post Modal
function openJobPostModal() {
  document.getElementById('jobPostModal').style.display = 'block';
  document.getElementById('jobPostForm').reset();
}

function closeJobPostModal() {
  document.getElementById('jobPostModal').style.display = 'none';
}

function submitJobPost() {
  const title = document.getElementById('jobTitle').value;
  const description = document.getElementById('jobDescription').value;
  const location = document.getElementById('jobLocation').value;
  const jobType = document.getElementById('jobTypeSelect').value;
  const salaryMin = document.getElementById('jobSalaryMin').value;
  const salaryMax = document.getElementById('jobSalaryMax').value;
  const qualifications = document.getElementById('jobQualifications').value;
  const responsibilities = document.getElementById('jobResponsibilities').value;
  const skills = document.getElementById('jobSkills').value;
  
  if (!title || !description || !location || !jobType) {
    showToast('Please fill in all required fields', 'error');
    return;
  }
  
  const newJob = {
    id: `job_${Date.now()}`,
    title,
    company: state.currentUser.company || 'Company',
    location,
    salary_min: parseInt(salaryMin) || 50000,
    salary_max: parseInt(salaryMax) || 80000,
    job_type: jobType,
    description,
    qualifications: qualifications || 'Not specified',
    responsibilities: responsibilities || 'Not specified',
    skills: skills ? skills.split(',').map(s => s.trim()) : [],
    posted_date: new Date().toISOString(),
    application_count: 0,
    view_count: 0,
    employer_id: state.currentUser.id,
    active: true
  };
  
  state.jobs.unshift(newJob);
  closeJobPostModal();
  showToast('Job posted successfully!', 'success');
  
  renderEmployerDashboard();
  updateStats();
}

// Seeker Dashboard
function renderSeekerDashboard() {
  document.getElementById('seekerName').textContent = state.currentUser.name;
  
  const userApps = state.applications.filter(app => app.seeker_id === state.currentUser.id);
  // Sort by date (newest first)
  userApps.sort((a, b) => new Date(b.applied_date) - new Date(a.applied_date));
  
  const pendingApps = userApps.filter(app => app.status === 'pending').length;
  const interviewedApps = userApps.filter(app => app.status === 'interviewed').length;
  
  document.getElementById('seekerTotalApps').textContent = userApps.length;
  document.getElementById('seekerPendingApps').textContent = pendingApps;
  document.getElementById('seekerInterviewedApps').textContent = interviewedApps;
  
  const container = document.getElementById('seekerApplicationsList');
  const emptyState = document.getElementById('seekerEmptyState');
  
  if (userApps.length === 0) {
    container.style.display = 'none';
    emptyState.style.display = 'block';
  } else {
    container.style.display = 'block';
    emptyState.style.display = 'none';
    
    container.innerHTML = userApps.map(app => {
      const job = state.jobs.find(j => j.id === app.job_id);
      return `
        <div class="application-card">
          <div class="application-header">
            <div>
              <h3 class="application-title">${job ? job.title : 'Job Not Found'}</h3>
              <p class="application-company">${job ? job.company : ''}</p>
            </div>
            <span class="status-badge status-${app.status}">${app.status}</span>
          </div>
          <div class="application-date">Applied ${getRelativeTime(app.applied_date)}</div>
          ${app.status === 'accepted' ? `
            <div class="congratulations-message">
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <polyline points="20 6 9 17 4 12"></polyline>
              </svg>
              <span>Congratulations! Your application has been accepted!</span>
            </div>
          ` : ''}
          ${app.employer_notes && app.status === 'rejected' ? `
            <div class="application-notes"><strong>Employer feedback:</strong> ${app.employer_notes}</div>
          ` : ''}
          ${app.employer_notes && app.status !== 'rejected' ? `
            <div class="application-notes"><strong>Employer notes:</strong> ${app.employer_notes}</div>
          ` : ''}
          <div class="status-timeline">
            <span>Status: ${app.status}</span>
            ${app.reviewed_date ? `<span> • Reviewed ${getRelativeTime(app.reviewed_date)}</span>` : ''}
          </div>
        </div>
      `;
    }).join('');
  }
}

// Dashboard Tab Switching
function switchDashboardTab(tabName) {
  document.querySelectorAll('.tab-btn').forEach(btn => {
    btn.classList.toggle('active', btn.dataset.tab === tabName);
  });
  
  document.querySelectorAll('.tab-content').forEach(content => {
    content.classList.remove('active');
    content.style.display = 'none';
  });
  
  if (tabName === 'my-jobs') {
    document.getElementById('myJobsTab').classList.add('active');
    document.getElementById('myJobsTab').style.display = 'block';
  } else if (tabName === 'all-applications') {
    document.getElementById('allApplicationsTab').classList.add('active');
    document.getElementById('allApplicationsTab').style.display = 'block';
    renderAllApplications();
  }
}

// Notification Badge Update
function updateNotificationBadge() {
  if (!state.currentUser || state.currentUser.role !== 'employer') {
    document.getElementById('notificationBell').style.display = 'none';
    return;
  }
  
  const employerJobs = state.jobs.filter(job => job.employer_id === state.currentUser.id);
  const newApps = state.applications.filter(app => 
    employerJobs.some(job => job.id === app.job_id) && !app.viewed_by_employer
  );
  
  const bellElement = document.getElementById('notificationBell');
  const badgeElement = document.getElementById('notificationBadge');
  
  if (newApps.length > 0) {
    bellElement.style.display = 'block';
    badgeElement.textContent = newApps.length;
  } else {
    bellElement.style.display = 'none';
  }
}

// Render All Applications for Employer
function renderAllApplications() {
  const employerJobs = state.jobs.filter(job => job.employer_id === state.currentUser.id);
  let allApps = state.applications.filter(app => 
    employerJobs.some(job => job.id === app.job_id)
  );
  
  // Apply filters
  const searchQuery = document.getElementById('applicantSearch')?.value.toLowerCase() || '';
  const statusFilter = document.getElementById('statusFilter')?.value || '';
  
  if (searchQuery) {
    allApps = allApps.filter(app => 
      app.seeker_name.toLowerCase().includes(searchQuery) ||
      app.seeker_email.toLowerCase().includes(searchQuery)
    );
  }
  
  if (statusFilter) {
    allApps = allApps.filter(app => app.status === statusFilter);
  }
  
  const container = document.getElementById('allApplicationsList');
  const emptyState = document.getElementById('noApplicationsState');
  
  if (allApps.length === 0) {
    container.innerHTML = '';
    emptyState.style.display = 'block';
    return;
  }
  
  emptyState.style.display = 'none';
  
  // Group by job
  // Sort by date (newest first)
  allApps.sort((a, b) => new Date(b.applied_date) - new Date(a.applied_date));
  
  const groupedApps = {};
  allApps.forEach(app => {
    if (!groupedApps[app.job_id]) {
      groupedApps[app.job_id] = [];
    }
    groupedApps[app.job_id].push(app);
  });
  
  container.innerHTML = Object.keys(groupedApps).map(jobId => {
    const job = state.jobs.find(j => j.id === jobId);
    const apps = groupedApps[jobId];
    
    if (!job) return '';
    
    const pendingCount = apps.filter(a => a.status === 'pending').length;
    const reviewedCount = apps.filter(a => a.status === 'reviewed').length;
    const acceptedCount = apps.filter(a => a.status === 'accepted').length;
    
    return `
      <div class="job-applications-group" data-job-id="${jobId}">
        <div class="job-group-header">
          <h3 class="job-group-title">${job ? job.title : 'Unknown Job'}</h3>
          <div class="job-group-meta">
            <span>${apps.length} application${apps.length !== 1 ? 's' : ''}</span>
            <span> • </span>
            <span class="app-stats-badge">
              <span class="stat-item">${pendingCount} pending</span>
              <span class="stat-separator">•</span>
              <span class="stat-item">${reviewedCount} reviewed</span>
              <span class="stat-separator">•</span>
              <span class="stat-item">${acceptedCount} accepted</span>
            </span>
          </div>
        </div>
        <div class="applications-grid">
          ${apps.map(app => createApplicationCard(app)).join('')}
        </div>
      </div>
    `;
  }).join('');
  
  // Add event listeners
  allApps.forEach(app => {
    const viewBtn = document.querySelector(`[data-view-app="${app.id}"]`);
    const acceptBtn = document.querySelector(`[data-accept-app="${app.id}"]`);
    const rejectBtn = document.querySelector(`[data-reject-app="${app.id}"]`);
    
    if (viewBtn) viewBtn.addEventListener('click', () => openApplicationDetailModal(app.id));
    if (acceptBtn) acceptBtn.addEventListener('click', () => showConfirmation('accept', app));
    if (rejectBtn) rejectBtn.addEventListener('click', () => showConfirmation('reject', app));
  });
}

// Create Application Card
function createApplicationCard(app) {
  const initials = app.seeker_name.split(' ').map(n => n[0]).join('').toUpperCase();
  const coverPreview = app.cover_letter.length > 150 
    ? app.cover_letter.substring(0, 150) + '...' 
    : app.cover_letter;
  
  return `
    <div class="application-item-card">
      <div class="applicant-avatar">${initials}</div>
      <div class="application-item-info">
        <h4 class="applicant-name">${app.seeker_name}</h4>
        <p class="applicant-email">${app.seeker_email}</p>
        <div class="applicant-skills">
          ${app.seeker_skills.map(skill => `<span class="skill-tag">${skill}</span>`).join('')}
        </div>
        <div class="cover-letter-preview">
          ${coverPreview}
          ${app.cover_letter.length > 150 ? `<span class="read-more" data-view-app="${app.id}">Read more</span>` : ''}
        </div>
        <div class="application-date">Applied ${getRelativeTime(app.applied_date)}</div>
      </div>
      <div class="application-item-actions">
        <span class="status-badge status-${app.status}">${app.status}</span>
        <div class="action-buttons">
          <button class="btn btn-outline btn-sm" data-view-app="${app.id}">View Details</button>
          ${app.status !== 'accepted' && app.status !== 'rejected' ? `
            <button class="btn btn-sm" data-accept-app="${app.id}" style="background-color: var(--color-green-500); color: white;">Accept</button>
            <button class="btn btn-sm" data-reject-app="${app.id}" style="background-color: var(--color-red-600); color: white;">Reject</button>
          ` : ''}
        </div>
      </div>
    </div>
  `;
}

// Open Application Detail Modal
function openApplicationDetailModal(appId) {
  const app = state.applications.find(a => a.id === appId);
  if (!app) return;
  
  // Mark as viewed
  if (!app.viewed_by_employer) {
    app.viewed_by_employer = true;
    if (app.status === 'pending') {
      app.status = 'reviewed';
      app.reviewed_date = new Date().toISOString();
    }
    updateNotificationBadge();
  }
  
  const modal = document.getElementById('applicationDetailModal');
  const content = document.getElementById('applicationDetailContent');
  
  content.innerHTML = `
    <div class="application-detail-section">
      <h4>Applicant Information</h4>
      <div class="detail-grid">
        <div class="detail-item">
          <span class="detail-label">Name</span>
          <span class="detail-value">${app.seeker_name}</span>
        </div>
        <div class="detail-item">
          <span class="detail-label">Email</span>
          <span class="detail-value">${app.seeker_email}</span>
        </div>
        <div class="detail-item">
          <span class="detail-label">Applied Date</span>
          <span class="detail-value">${new Date(app.applied_date).toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' })}</span>
        </div>
        <div class="detail-item">
          <span class="detail-label">Current Status</span>
          <span class="detail-value"><span class="status-badge status-${app.status}">${app.status}</span></span>
        </div>
      </div>
      <div class="detail-item">
        <span class="detail-label">Skills</span>
        <div class="applicant-skills">
          ${app.seeker_skills.map(skill => `<span class="skill-tag">${skill}</span>`).join('')}
        </div>
      </div>
      <div class="detail-item" style="margin-top: 12px;">
        <span class="detail-label">Resume</span>
        <span class="detail-value">${app.resume_file}</span>
      </div>
    </div>
    
    <div class="application-detail-section">
      <h4>Cover Letter</h4>
      <div class="cover-letter-full">${app.cover_letter}</div>
    </div>
    
    <div class="application-detail-section status-update-section">
      <h4>Update Status</h4>
      <select id="statusUpdateSelect" class="form-control">
        <option value="pending" ${app.status === 'pending' ? 'selected' : ''}>Pending</option>
        <option value="reviewed" ${app.status === 'reviewed' ? 'selected' : ''}>Reviewed</option>
        <option value="shortlisted" ${app.status === 'shortlisted' ? 'selected' : ''}>Shortlisted</option>
        <option value="interviewed" ${app.status === 'interviewed' ? 'selected' : ''}>Interviewed</option>
        <option value="accepted" ${app.status === 'accepted' ? 'selected' : ''}>Accepted</option>
        <option value="rejected" ${app.status === 'rejected' ? 'selected' : ''}>Rejected</option>
      </select>
    </div>
    
    <div class="application-detail-section notes-section">
      <h4>Employer Notes</h4>
      <textarea id="employerNotesTextarea" class="form-control" placeholder="Add notes for the applicant...">${app.employer_notes || ''}</textarea>
      <button class="btn btn-primary" id="saveNotesBtn" style="margin-top: 12px;">Save Notes</button>
    </div>
  `;
  
  modal.dataset.appId = appId;
  modal.style.display = 'block';
  
  // Add event listener for status update
  setTimeout(() => {
    document.getElementById('statusUpdateSelect')?.addEventListener('change', (e) => {
      updateApplicationStatus(appId, e.target.value);
    });
    
    document.getElementById('saveNotesBtn')?.addEventListener('click', () => {
      const notes = document.getElementById('employerNotesTextarea').value;
      saveEmployerNotes(appId, notes);
    });
  }, 100);
}

// Close Application Detail Modal
function closeApplicationDetailModal() {
  document.getElementById('applicationDetailModal').style.display = 'none';
}

// Update Application Status
function updateApplicationStatus(appId, newStatus) {
  const app = state.applications.find(a => a.id === appId);
  if (app) {
    app.status = newStatus;
    showToast(`Application status updated to ${newStatus}`, 'success');
    renderAllApplications();
    updateNotificationBadge();
  }
}

// Save Employer Notes
function saveEmployerNotes(appId, notes) {
  const app = state.applications.find(a => a.id === appId);
  if (app) {
    app.employer_notes = notes;
    showToast('Notes saved successfully', 'success');
  }
}

// Show Confirmation Dialog
function showConfirmation(action, app) {
  const modal = document.getElementById('confirmationDialog');
  const title = document.getElementById('confirmationTitle');
  const message = document.getElementById('confirmationMessage');
  const confirmBtn = document.getElementById('confirmAction');
  
  title.textContent = `Confirm ${action === 'accept' ? 'Accept' : 'Reject'}`;
  message.textContent = `Are you sure you want to ${action} the application from ${app.seeker_name}?`;
  
  if (action === 'reject') {
    confirmBtn.style.backgroundColor = 'var(--color-red-600)';
  } else {
    confirmBtn.style.backgroundColor = 'var(--color-green-500)';
  }
  
  modal.dataset.appId = app.id;
  modal.dataset.action = action;
  modal.style.display = 'block';
  
  // Remove old listener and add new one
  const newConfirmBtn = confirmBtn.cloneNode(true);
  confirmBtn.parentNode.replaceChild(newConfirmBtn, confirmBtn);
  
  newConfirmBtn.addEventListener('click', () => {
    executeApplicationAction(action, app.id);
    closeConfirmationDialog();
  });
}

// Close Confirmation Dialog
function closeConfirmationDialog() {
  document.getElementById('confirmationDialog').style.display = 'none';
}

// Execute Application Action (Accept/Reject)
function executeApplicationAction(action, appId) {
  const app = state.applications.find(a => a.id === appId);
  if (app) {
    app.status = action === 'accept' ? 'accepted' : 'rejected';
    showToast(`Application ${action === 'accept' ? 'accepted' : 'rejected'} successfully!`, 'success');
    renderAllApplications();
    updateNotificationBadge();
  }
}

// Handle Application Action from Detail Modal
function handleApplicationAction(action) {
  const modal = document.getElementById('applicationDetailModal');
  const appId = modal.dataset.appId;
  const app = state.applications.find(a => a.id === appId);
  
  if (app) {
    showConfirmation(action, app);
  }
}

// Filter Applications
function filterApplications() {
  renderAllApplications();
}

// Employer Dashboard
function renderEmployerDashboard() {
  document.getElementById('employerName').textContent = state.currentUser.name;
  
  const employerJobs = state.jobs.filter(job => job.employer_id === state.currentUser.id);
  const activeJobs = employerJobs.filter(job => job.active).length;
  const totalApps = state.applications.filter(app => 
    employerJobs.some(job => job.id === app.job_id)
  ).length;
  const totalViews = employerJobs.reduce((sum, job) => sum + job.view_count, 0);
  
  document.getElementById('employerActiveJobs').textContent = activeJobs;
  document.getElementById('employerTotalApps').textContent = totalApps;
  document.getElementById('employerTotalViews').textContent = totalViews;
  
  const container = document.getElementById('employerJobsList');
  const emptyState = document.getElementById('employerEmptyState');
  
  if (employerJobs.length === 0) {
    container.style.display = 'none';
    emptyState.style.display = 'block';
  } else {
    container.style.display = 'block';
    emptyState.style.display = 'none';
    
    container.innerHTML = employerJobs.map(job => `
      <div class="employer-job-card">
        <div class="employer-job-header">
          <div class="employer-job-title-group">
            <h3 class="employer-job-title">
              ${job.title}
              <span class="${job.active ? 'active-badge' : 'inactive-badge'}">${job.active ? 'Active' : 'Inactive'}</span>
            </h3>
            <p class="employer-job-description">${job.description}</p>
          </div>
        </div>
        <div class="employer-job-stats">
          <span>📍 ${job.location}</span>
          <span>💰 $${(job.salary_min / 1000).toFixed(0)}k - $${(job.salary_max / 1000).toFixed(0)}k</span>
          <span>📝 ${job.application_count} applications</span>
          <span>👁️ ${job.view_count} views</span>
          <span>📅 Posted ${getRelativeTime(job.posted_date)}</span>
        </div>
        <div class="employer-job-actions">
          <button class="btn btn-primary btn-sm" onclick="viewJobApplicationsInTab('${job.id}')">View Applications (${job.application_count})</button>
          <button class="btn btn-outline btn-sm" onclick="toggleJobStatus('${job.id}')">${job.active ? 'Deactivate' : 'Activate'}</button>
          <button class="btn btn-outline btn-sm" onclick="deleteJob('${job.id}')">Delete</button>
        </div>
      </div>
    `).join('');
  }
}

// Employer actions
window.viewJobApplicationsInTab = function(jobId) {
  switchDashboardTab('all-applications');
  
  // Scroll to the job group
  setTimeout(() => {
    const jobGroup = document.querySelector(`[data-job-id="${jobId}"]`);
    if (jobGroup) {
      jobGroup.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  }, 100);
};

window.toggleJobStatus = function(jobId) {
  const job = state.jobs.find(j => j.id === jobId);
  if (job) {
    job.active = !job.active;
    showToast(`Job ${job.active ? 'activated' : 'deactivated'}`, 'success');
    renderEmployerDashboard();
    updateStats();
  }
};

window.deleteJob = function(jobId) {
  if (confirm('Are you sure you want to delete this job posting?')) {
    state.jobs = state.jobs.filter(j => j.id !== jobId);
    state.applications = state.applications.filter(app => app.job_id !== jobId);
    showToast('Job deleted successfully', 'success');
    renderEmployerDashboard();
    updateStats();
    updateNotificationBadge();
  }
};

// Update statistics
function updateStats() {
  const activeJobs = state.jobs.filter(job => job.active).length;
  const companies = new Set(state.jobs.map(job => job.company)).size;
  const totalApplications = state.applications.length;
  
  document.getElementById('statActiveJobs').textContent = activeJobs;
  document.getElementById('statCompanies').textContent = companies;
  document.getElementById('statApplications').textContent = totalApplications;
}

// Utility functions
function getRelativeTime(dateString) {
  const date = new Date(dateString);
  const now = new Date();
  const diff = now - date;
  
  const minutes = Math.floor(diff / 60000);
  const hours = Math.floor(diff / 3600000);
  const days = Math.floor(diff / 86400000);
  
  if (days > 0) return `${days} day${days > 1 ? 's' : ''} ago`;
  if (hours > 0) return `${hours} hour${hours > 1 ? 's' : ''} ago`;
  if (minutes > 0) return `${minutes} minute${minutes > 1 ? 's' : ''} ago`;
  return 'Just now';
}

function showToast(message, type = 'success') {
  const toast = document.getElementById('toast');
  toast.textContent = message;
  toast.className = `toast ${type} show`;
  
  setTimeout(() => {
    toast.className = 'toast';
  }, 3000);
}

// Initialize on load
document.addEventListener('DOMContentLoaded', init);